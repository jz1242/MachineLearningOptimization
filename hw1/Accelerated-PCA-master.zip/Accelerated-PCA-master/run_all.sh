#!/bin/bash

for root in `ls data`
do
    root=${root%.txt}
    julia Network.jl $root &
done
